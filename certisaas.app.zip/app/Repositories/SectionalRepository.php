<?php

namespace App\Repositories;

use Prettus\Repository\Contracts\RepositoryInterface;

/**
 * Interface SectionalRepository.
 *
 * @package namespace App\Repositories;
 */
interface SectionalRepository extends RepositoryInterface
{
    //
}
