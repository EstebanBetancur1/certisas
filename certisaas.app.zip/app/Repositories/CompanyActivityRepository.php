<?php

namespace App\Repositories;

use Prettus\Repository\Contracts\RepositoryInterface;

/**
 * Interface CompanyActivityRepository.
 *
 * @package namespace App\Repositories;
 */
interface CompanyActivityRepository extends RepositoryInterface
{
    //
}
