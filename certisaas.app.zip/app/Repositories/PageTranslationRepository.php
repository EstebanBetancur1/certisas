<?php

namespace App\Repositories;

use Prettus\Repository\Contracts\RepositoryInterface;

/**
 * Interface PageTranslationRepository.
 *
 * @package namespace App\Repositories;
 */
interface PageTranslationRepository extends RepositoryInterface
{
    //
}
