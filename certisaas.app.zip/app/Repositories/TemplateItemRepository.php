<?php

namespace App\Repositories;

use Prettus\Repository\Contracts\RepositoryInterface;

/**
 * Interface TemplateItemRepository.
 *
 * @package namespace App\Repositories;
 */
interface TemplateItemRepository extends RepositoryInterface
{
    //
}
