<?php

namespace App\Repositories;

use Prettus\Repository\Contracts\RepositoryInterface;

/**
 * Interface LanguageRepository.
 *
 * @package namespace App\Repositories;
 */
interface LanguageRepository extends RepositoryInterface
{
    //
}
