<?php

namespace App\Repositories;

use Prettus\Repository\Contracts\RepositoryInterface;

/**
 * Interface MunicipioRepository.
 *
 * @package namespace App\Repositories;
 */
interface MunicipioRepository extends RepositoryInterface
{
    //
}
