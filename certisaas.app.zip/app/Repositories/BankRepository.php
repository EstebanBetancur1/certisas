<?php

namespace App\Repositories;

use Prettus\Repository\Contracts\RepositoryInterface;

/**
 * Interface BankRepository.
 *
 * @package namespace App\Repositories;
 */
interface BankRepository extends RepositoryInterface
{
    //
}
