<?php

namespace App\Repositories;

use Prettus\Repository\Contracts\RepositoryInterface;

/**
 * Interface EntityRepository.
 *
 * @package namespace App\Repositories;
 */
interface EntityRepository extends RepositoryInterface
{
    //
}
