<?php

namespace App\Repositories;

use Prettus\Repository\Contracts\RepositoryInterface;

/**
 * Interface EmissionRepository.
 *
 * @package namespace App\Repositories;
 */
interface EmissionRepository extends RepositoryInterface
{
    //
}
