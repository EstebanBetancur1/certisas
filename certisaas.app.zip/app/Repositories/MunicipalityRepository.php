<?php

namespace App\Repositories;

use Prettus\Repository\Contracts\RepositoryInterface;

/**
 * Interface MunicipalityRepository.
 *
 * @package namespace App\Repositories;
 */
interface MunicipalityRepository extends RepositoryInterface
{
    //
}
