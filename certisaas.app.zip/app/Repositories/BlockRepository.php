<?php

namespace App\Repositories;

use Prettus\Repository\Contracts\RepositoryInterface;

/**
 * Interface BlockRepository.
 *
 * @package namespace App\Repositories;
 */
interface BlockRepository extends RepositoryInterface
{
    //
}
