<?php

namespace App\Repositories;

use Prettus\Repository\Contracts\RepositoryInterface;

/**
 * Interface RequestRepository.
 *
 * @package namespace App\Repositories;
 */
interface RequestRepository extends RepositoryInterface
{
    //
}
