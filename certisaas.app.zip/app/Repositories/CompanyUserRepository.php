<?php

namespace App\Repositories;

use Prettus\Repository\Contracts\RepositoryInterface;

/**
 * Interface CompanyUserRepository.
 *
 * @package namespace App\Repositories;
 */
interface CompanyUserRepository extends RepositoryInterface
{
    //
}
