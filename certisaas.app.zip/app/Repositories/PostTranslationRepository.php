<?php

namespace App\Repositories;

use Prettus\Repository\Contracts\RepositoryInterface;

/**
 * Interface PostTranslationRepository.
 *
 * @package namespace App\Repositories;
 */
interface PostTranslationRepository extends RepositoryInterface
{
    //
}
