<?php

namespace App\Repositories;

use Prettus\Repository\Contracts\RepositoryInterface;

/**
 * Interface DeclarationRepository.
 *
 * @package namespace App\Repositories;
 */
interface DeclarationRepository extends RepositoryInterface
{
    //
}
