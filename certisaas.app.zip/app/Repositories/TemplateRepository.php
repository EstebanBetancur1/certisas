<?php

namespace App\Repositories;

use Prettus\Repository\Contracts\RepositoryInterface;

/**
 * Interface TemplateRepository.
 *
 * @package namespace App\Repositories;
 */
interface TemplateRepository extends RepositoryInterface
{
    //
}
